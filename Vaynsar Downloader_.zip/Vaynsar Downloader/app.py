from flask import Flask, request, jsonify, send_file, abort, render_template
from yt_dlp import YoutubeDL
import uuid
import os
import threading
import subprocess
import logging
import time

app = Flask(__name__, template_folder="templates")
DOWNLOAD_DIR = "downloads"
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

logging.basicConfig(filename='download_errors.log', level=logging.ERROR)

active_downloads = {}
download_lock = threading.Lock()

def download_progress_hook(d):
    with download_lock:
        if d["status"] == "downloading":
            total_bytes = d.get("total_bytes") or d.get("total_bytes_estimate")
            if total_bytes:
                progress = (d.get("downloaded_bytes", 0) / total_bytes) * 100
                active_downloads[d["download_id"]]["progress"] = round(progress, 2)
        elif d["status"] == "finished":
            active_downloads[d["download_id"]]["progress"] = 100

def is_compatible_codec(video_path):
    try:
        result = subprocess.check_output(
            ["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
             "stream=codec_name", "-of", "default=noprint_wrappers=1:nokey=1", video_path],
            universal_newlines=True
        ).strip()
        return result == "h264"
    except:
        return False

def download_video(download_id, url, format_ext, quality, options):
    raw_path = f"{DOWNLOAD_DIR}/{download_id}"
    downloaded_file = f"{raw_path}.mp4"
    final_file = f"{raw_path}_h264.mp4"
    force_h264 = "force_h264" in options

    ydl_opts = {
        "format": f"bestvideo[ext=mp4][vcodec!*=av01][vcodec!*=vp9][height={quality}]+bestaudio[ext=m4a]/best[ext=mp4]",
        "outtmpl": downloaded_file,
        "merge_output_format": "mp4",
        "noplaylist": True,
        "quiet": True,
        "progress_hooks": [lambda d: download_progress_hook({**d, "download_id": download_id})]
    }

    try:
        with YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])

        if force_h264 or not is_compatible_codec(downloaded_file):
            command = [
                "ffmpeg", "-y",
                "-i", downloaded_file,
                "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23",
                "-c:a", "aac", "-b:a", "192k",
                final_file
            ]
            subprocess.run(command, check=True)
            os.remove(downloaded_file)
            final_output = final_file
        else:
            final_output = downloaded_file

        with download_lock:
            active_downloads[download_id]["status"] = "completed"
            active_downloads[download_id]["filepath"] = final_output
            active_downloads[download_id]["progress"] = 100

    except Exception as e:
        with download_lock:
            active_downloads[download_id]["status"] = "failed"
            active_downloads[download_id]["error"] = str(e)
        logging.error(f"Download {download_id} failed: {str(e)}")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/download", methods=["POST"])
def start_download():
    url = request.form["url"]
    format_ext = request.form["format"]
    quality = request.form["quality"].replace("p", "")
    if quality == "best_audio":
        quality = "4320"
    download_id = str(uuid.uuid4())

    with download_lock:
        active_downloads[download_id] = {
            "status": "queued",
            "progress": 0,
            "filepath": None,
            "error": None,
            "timestamp": time.time()
        }

    thread = threading.Thread(
        target=download_video,
        args=(download_id, url, format_ext, quality, request.form.getlist("options"))
    )
    thread.start()
    return jsonify({"download_id": download_id})

@app.route("/download/<download_id>/status")
def download_status(download_id):
    with download_lock:
        download = active_downloads.get(download_id)
        if not download:
            return abort(404)
        return jsonify({
            "status": download["status"],
            "progress": download["progress"],
            "error": download.get("error")
        })

@app.route("/download/<download_id>/file")
def download_file(download_id):
    with download_lock:
        download = active_downloads.get(download_id)
        if not download or download["status"] != "completed":
            return abort(404)
        filepath = download["filepath"]
    return send_file(filepath, as_attachment=True)

@app.route("/download/<download_id>/cancel", methods=["POST"])
def cancel_download(download_id):
    with download_lock:
        if download_id in active_downloads:
            active_downloads[download_id]["status"] = "canceled"
            return jsonify({"status": "canceled"})
        return abort(404)

@app.route("/thumbnail", methods=["POST"])
def fetch_thumbnail():
    url = request.json.get("url")
    try:
        with YoutubeDL({"quiet": True, "skip_download": True}) as ydl:
            info = ydl.extract_info(url, download=False)
            return jsonify({
                "title": info.get("title"),
                "duration": info.get("duration"),
                "thumbnail": info.get("thumbnail")
            })
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route("/thumbnail/download", methods=["POST"])
def download_thumbnail():
    import requests
    from io import BytesIO

    data = request.json
    url = data.get("thumbnail_url")
    try:
        response = requests.get(url)
        response.raise_for_status()
        return send_file(BytesIO(response.content), mimetype="image/jpeg", as_attachment=True, download_name="thumbnail.jpg")
    except Exception as e:
        return jsonify({"error": str(e)}), 400

def cleanup_downloads():
    while True:
        with download_lock:
            now = time.time()
            for download_id in list(active_downloads.keys()):
                d = active_downloads[download_id]
                if d["status"] in ["completed", "failed", "canceled"]:
                    if now - d.get("timestamp", now) > 3600:
                        del active_downloads[download_id]
        time.sleep(600)

if __name__ == "__main__":
    threading.Thread(target=cleanup_downloads, daemon=True).start()
    app.run(debug=True)
